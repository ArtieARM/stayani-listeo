<?php
/**
 * Embedding Manager Class
 * 
 * Handles OpenAI embedding generation and management
 * 
 * @package Listeo_AI_Search
 * @since 1.0.5
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Listeo_AI_Search_Embedding_Manager {
    
    /**
     * OpenAI API key
     * 
     * @var string
     */
    private $api_key;
    
    /**
     * Constructor
     * 
     * @param string $api_key OpenAI API key
     */
    public function __construct($api_key = '') {
        $this->api_key = $api_key ?: get_option('listeo_ai_search_api_key', '');
    }
    
    /**
     * Check if rate limit allows API call
     * 
     * @return bool True if call is allowed
     */
    private function check_rate_limit() {
        $rate_limit_key = 'listeo_ai_rate_limit_' . date('Y-m-d-H'); // Per hour limit
        $current_calls = get_transient($rate_limit_key) ?: 0;
        $max_calls_per_hour = get_option('listeo_ai_search_rate_limit_per_hour', 100); // Get from settings, default 100
        
        if ($current_calls >= $max_calls_per_hour) {
            error_log('Listeo AI Search: Rate limit exceeded (' . $current_calls . '/' . $max_calls_per_hour . ' per hour)');
            return false;
        }
        
        // Increment counter
        set_transient($rate_limit_key, $current_calls + 1, HOUR_IN_SECONDS);
        return true;
    }
    
    /**
     * Generate OpenAI embedding for text
     * 
     * @param string $text Text to generate embedding for
     * @return array|false Embedding array or false on failure
     * @throws Exception On API errors
     */
    public function generate_embedding($text) {
        if (empty($this->api_key)) {
            return false;
        }
        
        // Check rate limit before making API call
        if (!$this->check_rate_limit()) {
            throw new Exception('Rate limit exceeded. Please try again later.');
        }
        
        $response = wp_remote_post('https://api.openai.com/v1/embeddings', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => 'text-embedding-3-small',
                'input' => $text,
            )),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            throw new Exception('OpenAI API request failed: ' . $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            throw new Exception('OpenAI API error: ' . $body['error']['message']);
        }
        
        return $body['data'][0]['embedding'] ?? false;
    }
    
    /**
     * Get listing content formatted for embedding generation using structured data approach
     * 
     * @param int $listing_id Listing post ID
     * @return string Structured content for embedding
     */
    public function get_listing_content_for_embedding($listing_id) {
        $post = get_post($listing_id);
        
        if (!$post || $post->post_type !== 'listing') {
            return '';
        }
        
        $structured_content = "";
        
        // TIER 1: Core Business Identity (Highest Priority)
        $structured_content .= "BUSINESS_NAME: " . get_the_title($listing_id) . ". ";
        
        $primary_category = $this->get_primary_category($listing_id);
        if ($primary_category) {
            $structured_content .= "PRIMARY_CATEGORY: " . $primary_category . ". ";
        }
        
        $listing_type = get_post_meta($listing_id, '_listing_type', true);
        if ($listing_type) {
            $structured_content .= "BUSINESS_TYPE: " . $listing_type . ". ";
        }
        
        // TIER 2: Location Information (Critical for geographic searches)
        $location_info = $this->get_structured_location($listing_id);
        if ($location_info) {
            $structured_content .= "LOCATION: " . $location_info . ". ";
        }
        
        // TIER 3: Official Business Information
        $verified_amenities = $this->get_verified_amenities($listing_id);
        if ($verified_amenities) {
            $structured_content .= "OFFICIAL_AMENITIES: " . $verified_amenities . ". ";
        }
        
        $verified_features = $this->get_verified_features($listing_id);
        if ($verified_features) {
            $structured_content .= "VERIFIED_FEATURES: " . $verified_features . ". ";
        }
        
        // TIER 4: Owner/Official Descriptions (High Authority)
        $owner_description = $this->get_owner_description($listing_id);
        if ($owner_description) {
            $structured_content .= "OWNER_DESCRIPTION: " . $owner_description . ". ";
        }
        
        $business_details = $this->get_business_details($listing_id);
        if ($business_details) {
            $structured_content .= "BUSINESS_DETAILS: " . $business_details . ". ";
        }
        
        // TIER 5: Operating Information
        $operating_hours = $this->get_formatted_hours($listing_id);
        if ($operating_hours) {
            $structured_content .= "OPERATING_HOURS: " . $operating_hours . ". ";
        }
        
        $pricing_info = $this->get_pricing_info($listing_id);
        if ($pricing_info) {
            $structured_content .= "PRICING: " . $pricing_info . ". ";
        }
        
        // TIER 6: User-Generated Content (Lower Priority but still valuable)
        $raw_reviews = $this->get_raw_reviews_for_embedding($listing_id);
        if ($raw_reviews) {
            $structured_content .= "USER_REVIEWS: " . $raw_reviews . ". ";
        }
        
        return trim($structured_content);
    }
    
    /**
     * Get primary category for a listing with intelligent fallback
     * 
     * @param int $listing_id Listing post ID
     * @return string Primary category
     */
    private function get_primary_category($listing_id) {
        // Try listing-specific categories first
        $listing_type = get_post_meta($listing_id, '_listing_type', true);
        
        switch ($listing_type) {
            case 'service':
                $categories = wp_get_post_terms($listing_id, 'service_category', array('fields' => 'names'));
                break;
            case 'rental':
                $categories = wp_get_post_terms($listing_id, 'rental_category', array('fields' => 'names'));
                break;
            case 'event':
                $categories = wp_get_post_terms($listing_id, 'event_category', array('fields' => 'names'));
                break;
            case 'classifieds':
                $categories = wp_get_post_terms($listing_id, 'classifieds_category', array('fields' => 'names'));
                break;
            default:
                $categories = wp_get_post_terms($listing_id, 'listing_category', array('fields' => 'names'));
                break;
        }
        
        if (!is_wp_error($categories) && !empty($categories)) {
            return $categories[0]; // Return the first (primary) category
        }
        
        // Fallback to general listing category
        $general_categories = wp_get_post_terms($listing_id, 'listing_category', array('fields' => 'names'));
        if (!is_wp_error($general_categories) && !empty($general_categories)) {
            return $general_categories[0];
        }
        
        return '';
    }
    
    /**
     * Get structured location information
     * 
     * @param int $listing_id Listing post ID
     * @return string Formatted location
     */
    private function get_structured_location($listing_id) {
        $location_parts = array();
        
        // Get friendly address first (most complete)
        $friendly_address = get_post_meta($listing_id, '_friendly_address', true);
        if ($friendly_address) {
            return $friendly_address;
        }
        
        // Build from components
        $address_data = get_post_meta($listing_id, '_address', true);
        if (is_array($address_data)) {
            if (!empty($address_data['street'])) {
                $location_parts[] = $address_data['street'];
            }
            if (!empty($address_data['city'])) {
                $location_parts[] = $address_data['city'];
            }
            if (!empty($address_data['state'])) {
                $location_parts[] = $address_data['state'];
            }
            if (!empty($address_data['country'])) {
                $location_parts[] = $address_data['country'];
            }
        }
        
        // Add region if available
        $regions = wp_get_post_terms($listing_id, 'region', array('fields' => 'names'));
        if (!is_wp_error($regions) && !empty($regions)) {
            $location_parts[] = $regions[0];
        }
        
        return implode(', ', array_filter($location_parts));
    }
    
    /**
     * Get verified amenities (from official sources)
     * 
     * @param int $listing_id Listing post ID
     * @return string Comma-separated amenities
     */
    private function get_verified_amenities($listing_id) {
        $amenities = array();
        
        // Get features from meta
        $features = get_post_meta($listing_id, '_features', true);
        if ($features && is_array($features)) {
            $amenities = array_merge($amenities, $features);
        }
        
        // Get listing features taxonomy
        $feature_terms = wp_get_post_terms($listing_id, 'listing_feature', array('fields' => 'names'));
        if (!is_wp_error($feature_terms) && !empty($feature_terms)) {
            $amenities = array_merge($amenities, $feature_terms);
        }
        
        // Filter out duplicates and empty values
        $amenities = array_filter(array_unique($amenities));
        
        return implode(', ', $amenities);
    }
    
    /**
     * Get verified features (distinct from amenities)
     * 
     * @param int $listing_id Listing post ID
     * @return string Comma-separated features
     */
    private function get_verified_features($listing_id) {
        $features = array();
        
        // Check for specific feature flags
        $has_gallery = get_post_meta($listing_id, '_gallery', true);
        if (!empty($has_gallery)) {
            $features[] = 'Photo Gallery Available';
        }
        
        $has_video = get_post_meta($listing_id, '_video', true);
        if (!empty($has_video)) {
            $features[] = 'Video Content Available';
        }
        
        $website = get_post_meta($listing_id, '_website', true);
        if (!empty($website)) {
            $features[] = 'Official Website';
        }
        
        $phone = get_post_meta($listing_id, '_phone', true);
        if (!empty($phone)) {
            $features[] = 'Phone Contact Available';
        }
        
        return implode(', ', $features);
    }
    
    /**
     * Get owner/official description
     * 
     * @param int $listing_id Listing post ID
     * @return string Owner description
     */
    private function get_owner_description($listing_id) {
        $description_parts = array();
        
        // Post content (main description)
        $post = get_post($listing_id);
        if ($post && !empty($post->post_content)) {
            $description_parts[] = strip_tags($post->post_content);
        }
        
        // Post excerpt
        if ($post && !empty($post->post_excerpt)) {
            $description_parts[] = strip_tags($post->post_excerpt);
        }
        
        // Listing description meta
        $listing_description = get_post_meta($listing_id, '_listing_description', true);
        if (!empty($listing_description)) {
            $description_parts[] = strip_tags($listing_description);
        }
        
        // Tagline
        $tagline = get_post_meta($listing_id, '_tagline', true);
        if (!empty($tagline)) {
            $description_parts[] = $tagline;
        }
        
        // Combine and limit length
        $full_description = implode(' ', $description_parts);
        
        // Limit to reasonable length for embedding (about 200 words)
        $words = str_word_count($full_description, 1);
        if (count($words) > 200) {
            $full_description = implode(' ', array_slice($words, 0, 200));
        }
        
        return trim($full_description);
    }
    
    /**
     * Get business details (contact, keywords, etc.)
     * 
     * @param int $listing_id Listing post ID
     * @return string Business details
     */
    private function get_business_details($listing_id) {
        $details = array();
        
        $keywords = get_post_meta($listing_id, '_keywords', true);
        if (!empty($keywords)) {
            $details[] = $keywords;
        }
        
        $email = get_post_meta($listing_id, '_email', true);
        if (!empty($email)) {
            $details[] = 'Email contact available';
        }
        
        return implode(', ', $details);
    }
    
    /**
     * Get formatted operating hours
     * 
     * @param int $listing_id Listing post ID
     * @return string Formatted hours
     */
    private function get_formatted_hours($listing_id) {
        $opening_hours = get_post_meta($listing_id, '_opening_hours', true);
        
        if (empty($opening_hours)) {
            return '';
        }
        
        if (is_serialized($opening_hours)) {
            $hours_data = maybe_unserialize($opening_hours);
            if (is_array($hours_data)) {
                $hours_text = array();
                $has_24h = false;
                $typical_hours = true;
                
                foreach ($hours_data as $day => $hours) {
                    if (!empty($hours['opening']) && !empty($hours['closing'])) {
                        // Check for 24h operation
                        if ($hours['opening'] === '00:00' && $hours['closing'] === '23:59') {
                            $has_24h = true;
                        }
                        // Check for unusual hours (before 6 AM or after 11 PM)
                        $opening_hour = intval(substr($hours['opening'], 0, 2));
                        $closing_hour = intval(substr($hours['closing'], 0, 2));
                        if ($opening_hour < 6 || $closing_hour > 23) {
                            $typical_hours = false;
                        }
                        
                        $hours_text[] = ucfirst($day) . ' ' . $hours['opening'] . '-' . $hours['closing'];
                    }
                }
                
                // Provide semantic summaries for common patterns
                if ($has_24h) {
                    return '24 hour operation, ' . implode(', ', array_slice($hours_text, 0, 2));
                } elseif (!$typical_hours) {
                    return 'Extended hours available, ' . implode(', ', array_slice($hours_text, 0, 2));
                } else {
                    return implode(', ', array_slice($hours_text, 0, 3)); // Limit to 3 days
                }
            }
        }
        
        return 'Operating hours available';
    }
    
    /**
     * Get pricing information
     * 
     * @param int $listing_id Listing post ID
     * @return string Pricing info
     */
    private function get_pricing_info($listing_id) {
        $pricing_parts = array();
        
        $price_min = get_post_meta($listing_id, '_price_min', true);
        $price_max = get_post_meta($listing_id, '_price_max', true);
        
        if (!empty($price_min) || !empty($price_max)) {
            if (!empty($price_min) && !empty($price_max)) {
                $pricing_parts[] = "Price range {$price_min}-{$price_max}";
            } elseif (!empty($price_min)) {
                $pricing_parts[] = "Starting from {$price_min}";
            } else {
                $pricing_parts[] = "Up to {$price_max}";
            }
        }
        
        $price = get_post_meta($listing_id, '_price', true);
        if (!empty($price) && empty($pricing_parts)) {
            $pricing_parts[] = "Price {$price}";
        }
        
        return implode(', ', $pricing_parts);
    }
    
    /**
     * Get raw reviews for embedding (authentic user language)
     * 
     * @param int $listing_id Listing post ID
     * @return string Raw review content
     */
    private function get_raw_reviews_for_embedding($listing_id) {
        $review_content = array();
        
        // Get WordPress Reviews (max 5, rating >= 3.0)
        $wp_comments = get_comments(array(
            'post_id' => $listing_id,
            'status' => 'approve',
            'type__in' => array('comment', 'review'),
            'number' => 10, // Get more to filter for quality
            'orderby' => 'comment_date',
            'order' => 'DESC'
        ));
        
        $wp_count = 0;
        foreach ($wp_comments as $comment) {
            if ($wp_count >= 5) break; // Max 5 WordPress reviews
            
            if (!empty($comment->comment_content) && strlen($comment->comment_content) > 15) {
                $rating = get_comment_meta($comment->comment_ID, 'listeo-review-rating', true);
                
                // Skip negative reviews (below 3.0)
                if (!empty($rating) && floatval($rating) < 3.0) {
                    continue;
                }
                
                $content = strip_tags($comment->comment_content);
                $content = preg_replace('/\s+/', ' ', $content); // Clean whitespace
                $content = trim($content);
                
                if (!empty($content)) {
                    $review_content[] = "[WordPress Review] " . $content;
                    $wp_count++;
                }
            }
        }
        
        // Get Google Reviews (max 5, rating >= 3.0)
        $transient_name = 'listeo_reviews_' . $listing_id;
        $google_data = get_transient($transient_name);
        
        if (!empty($google_data) && isset($google_data['result']['reviews']) && is_array($google_data['result']['reviews'])) {
            $google_count = 0;
            
            foreach ($google_data['result']['reviews'] as $review) {
                if ($google_count >= 5) break; // Max 5 Google reviews
                
                if (!empty($review['text']) && strlen($review['text']) > 15) {
                    $rating = isset($review['rating']) ? floatval($review['rating']) : null;
                    
                    // Skip negative reviews (below 3.0)
                    if (!empty($rating) && $rating < 3.0) {
                        continue;
                    }
                    
                    $content = strip_tags($review['text']);
                    $content = preg_replace('/\s+/', ' ', $content); // Clean whitespace
                    $content = trim($content);
                    
                    if (!empty($content)) {
                        $review_content[] = "[Google Review] " . $content;
                        $google_count++;
                    }
                }
            }
        }
        
        return !empty($review_content) ? implode(' ', $review_content) : '';
    }
    
    /**
     * Extract meaningful insights from review data using semantic analysis
     * 
     * @param array $review_data Array of review data
     * @return string Meaningful review insights
     */
    private function extract_review_insights($review_data) {
        $insights = array();
        $rating_sum = 0;
        $rating_count = 0;
        $positive_themes = array();
        $negative_themes = array();
        
        foreach ($review_data as $review) {
            // Collect ratings
            if (!empty($review['rating']) && is_numeric($review['rating'])) {
                $rating_sum += $review['rating'];
                $rating_count++;
                
                // Analyze sentiment based on rating
                $rating_value = floatval($review['rating']);
                $content = $this->normalize_text($review['content']);
                
                if ($rating_value >= 4) {
                    // High rating - extract positive aspects
                    $themes = $this->extract_business_themes($content, 'positive');
                    $positive_themes = array_merge($positive_themes, $themes);
                } elseif ($rating_value <= 2) {
                    // Low rating - extract negative aspects
                    $themes = $this->extract_business_themes($content, 'negative');
                    $negative_themes = array_merge($negative_themes, $themes);
                }
            }
        }
        
        // Build insights starting with ratings
        if ($rating_count > 0) {
            $avg_rating = round($rating_sum / $rating_count, 1);
            $insights[] = "Average user rating {$avg_rating}/5 from {$rating_count} reviews";
            
            // Add rating distribution context
            if ($avg_rating >= 4.5) {
                $insights[] = "Consistently excellent customer satisfaction";
            } elseif ($avg_rating >= 4.0) {
                $insights[] = "Generally positive customer feedback";
            } elseif ($avg_rating >= 3.0) {
                $insights[] = "Mixed customer experiences";
            } else {
                $insights[] = "Below average customer satisfaction";
            }
        }
        
        // Add positive themes summary
        if (!empty($positive_themes)) {
            $top_positive = $this->summarize_themes($positive_themes);
            if (!empty($top_positive)) {
                $insights[] = "Customers appreciate: " . $top_positive;
            }
        }
        
        // Add areas for improvement (if any)
        if (!empty($negative_themes)) {
            $top_negative = $this->summarize_themes($negative_themes);
            if (!empty($top_negative)) {
                $insights[] = "Areas mentioned for improvement: " . $top_negative;
            }
        }
        
        return !empty($insights) ? implode('. ', $insights) : '';
    }
    
    /**
     * Extract business themes from review content using semantic patterns
     * 
     * @param string $content Normalized review content
     * @param string $sentiment_type 'positive' or 'negative'
     * @return array Array of business themes
     */
    private function extract_business_themes($content, $sentiment_type = 'positive') {
        $themes = array();
        
        // Universal business aspects that work across languages
        $business_patterns = array(
            'service' => array(
                'positive' => array('excellent', 'great', 'amazing', 'wonderful', 'fantastic', 'professional', 'friendly', 'helpful', 'courteous', 'attentive'),
                'negative' => array('poor', 'bad', 'terrible', 'rude', 'slow', 'unprofessional', 'unhelpful', 'disappointing')
            ),
            'quality' => array(
                'positive' => array('high quality', 'excellent', 'fresh', 'delicious', 'perfect', 'outstanding', 'superior'),
                'negative' => array('poor quality', 'stale', 'old', 'tasteless', 'inferior', 'substandard')
            ),
            'cleanliness' => array(
                'positive' => array('clean', 'spotless', 'hygienic', 'tidy', 'well-maintained'),
                'negative' => array('dirty', 'messy', 'unclean', 'unhygienic', 'poorly maintained')
            ),
            'value' => array(
                'positive' => array('affordable', 'reasonable', 'good value', 'worth it', 'fair price'),
                'negative' => array('expensive', 'overpriced', 'not worth it', 'poor value')
            ),
            'atmosphere' => array(
                'positive' => array('cozy', 'welcoming', 'comfortable', 'relaxing', 'pleasant', 'nice ambiance'),
                'negative' => array('noisy', 'uncomfortable', 'unwelcoming', 'chaotic', 'unpleasant')
            ),
            'location' => array(
                'positive' => array('convenient', 'accessible', 'easy to find', 'good location', 'central'),
                'negative' => array('difficult to find', 'inconvenient', 'poor location', 'hard to reach')
            ),
            'speed' => array(
                'positive' => array('fast', 'quick', 'prompt', 'efficient', 'timely'),
                'negative' => array('slow', 'delayed', 'long wait', 'inefficient', 'late')
            )
        );
        
        // Look for semantic patterns rather than exact word matches
        foreach ($business_patterns as $aspect => $patterns) {
            if (isset($patterns[$sentiment_type])) {
                foreach ($patterns[$sentiment_type] as $pattern) {
                    // Use flexible matching for universal concepts
                    if ($this->content_mentions_concept($content, $pattern, $aspect)) {
                        $themes[] = $aspect;
                        break; // Only count each aspect once per review
                    }
                }
            }
        }
        
        return $themes;
    }
    
    /**
     * Check if content mentions a business concept (language-flexible)
     * 
     * @param string $content Review content
     * @param string $pattern Pattern to look for
     * @param string $aspect Business aspect being checked
     * @return bool True if concept is mentioned
     */
    private function content_mentions_concept($content, $pattern, $aspect) {
        // Simple pattern matching for now - could be enhanced with ML/NLP
        $content_lower = mb_strtolower($content, 'UTF-8');
        
        // Direct pattern match
        if (strpos($content_lower, $pattern) !== false) {
            return true;
        }
        
        // Aspect-specific semantic hints (works across languages)
        switch ($aspect) {
            case 'service':
                // Look for service-related indicators
                if (preg_match('/\b(staff|personnel|service|waiter|waitress|employee|worker)\b/i', $content)) {
                    return $this->has_positive_context($content, $pattern);
                }
                break;
                
            case 'quality':
                // Look for quality-related indicators  
                if (preg_match('/\b(food|meal|dish|product|item|quality)\b/i', $content)) {
                    return $this->has_positive_context($content, $pattern);
                }
                break;
                
            case 'cleanliness':
                // Look for cleanliness indicators
                if (preg_match('/\b(clean|dirty|hygiene|maintenance|condition)\b/i', $content)) {
                    return $this->has_positive_context($content, $pattern);
                }
                break;
                
            case 'value':
                // Look for price/value indicators
                if (preg_match('/\b(price|cost|value|money|expensive|cheap|affordable)\b/i', $content)) {
                    return $this->has_positive_context($content, $pattern);
                }
                break;
                
            case 'atmosphere':
                // Look for atmosphere indicators
                if (preg_match('/\b(atmosphere|ambiance|environment|mood|feeling|vibe)\b/i', $content)) {
                    return $this->has_positive_context($content, $pattern);
                }
                break;
                
            case 'location':
                // Look for location indicators
                if (preg_match('/\b(location|place|address|find|parking|access)\b/i', $content)) {
                    return $this->has_positive_context($content, $pattern);
                }
                break;
                
            case 'speed':
                // Look for timing indicators
                if (preg_match('/\b(fast|slow|quick|wait|time|service|delivery)\b/i', $content)) {
                    return $this->has_positive_context($content, $pattern);
                }
                break;
        }
        
        return false;
    }
    
    /**
     * Check if the context around a mention is positive (language-flexible)
     * 
     * @param string $content Review content
     * @param string $pattern Pattern being checked
     * @return bool True if context seems positive
     */
    private function has_positive_context($content, $pattern) {
        // Universal positive/negative indicators
        $positive_indicators = array('good', 'great', 'excellent', 'amazing', 'wonderful', 'perfect', 'love', 'like', 'best', 'fantastic', 'awesome', 'nice', 'beautiful', 'comfortable', 'pleasant', 'satisfied', 'happy', 'recommend');
        $negative_indicators = array('bad', 'terrible', 'awful', 'worst', 'hate', 'dislike', 'poor', 'disappointing', 'unacceptable', 'disgusting', 'horrible', 'unsatisfied', 'unhappy', 'avoid', 'never');
        
        $positive_count = 0;
        $negative_count = 0;
        
        foreach ($positive_indicators as $indicator) {
            if (stripos($content, $indicator) !== false) {
                $positive_count++;
            }
        }
        
        foreach ($negative_indicators as $indicator) {
            if (stripos($content, $indicator) !== false) {
                $negative_count++;
            }
        }
        
        // Return true if more positive than negative indicators
        return $positive_count > $negative_count;
    }
    
    /**
     * Summarize themes into readable format
     * 
     * @param array $themes Array of theme occurrences
     * @return string Formatted theme summary
     */
    private function summarize_themes($themes) {
        if (empty($themes)) {
            return '';
        }
        
        // Count theme frequency
        $theme_counts = array_count_values($themes);
        arsort($theme_counts);
        
        // Convert to readable format
        $readable_themes = array();
        foreach ($theme_counts as $theme => $count) {
            switch ($theme) {
                case 'service':
                    $readable_themes[] = 'customer service';
                    break;
                case 'quality':
                    $readable_themes[] = 'product quality';
                    break;
                case 'cleanliness':
                    $readable_themes[] = 'cleanliness standards';
                    break;
                case 'value':
                    $readable_themes[] = 'value for money';
                    break;
                case 'atmosphere':
                    $readable_themes[] = 'atmosphere and ambiance';
                    break;
                case 'location':
                    $readable_themes[] = 'location and accessibility';
                    break;
                case 'speed':
                    $readable_themes[] = 'service speed';
                    break;
                default:
                    $readable_themes[] = $theme;
            }
            
            // Limit to top 3 themes
            if (count($readable_themes) >= 3) {
                break;
            }
        }
        
        return implode(', ', $readable_themes);
    }
    
    /**
     * Normalize text for language-agnostic processing
     * 
     * @param string $text Input text
     * @return string Normalized text
     */
    private function normalize_text($text) {
        // Convert to lowercase
        $text = mb_strtolower($text, 'UTF-8');
        
        // Remove HTML tags
        $text = strip_tags($text);
        
        // Remove excessive whitespace
        $text = preg_replace('/\s+/', ' ', $text);
        
        return trim($text);
    }
    
    /**
     * Get review data in structured format
     * 
     * @param int $listing_id Listing post ID
     * @return array Array of review data
     */
    private function get_listing_reviews_data($listing_id) {
        $all_reviews = array();
        
        // Get WordPress Comments & Reviews
        $wp_comments = get_comments(array(
            'post_id' => $listing_id,
            'status' => 'approve',
            'type__in' => array('comment', 'review'),
            'number' => 20, // Reduced for better performance
            'orderby' => 'comment_date',
            'order' => 'DESC'
        ));
        
        foreach ($wp_comments as $comment) {
            if (!empty($comment->comment_content) && strlen($comment->comment_content) > 10) {
                $rating = get_comment_meta($comment->comment_ID, 'listeo-review-rating', true);
                
                $all_reviews[] = array(
                    'type' => 'wordpress',
                    'content' => strip_tags($comment->comment_content),
                    'rating' => $rating ? floatval($rating) : null,
                    'author' => $comment->comment_author
                );
            }
        }
        
        // Get Google Reviews
        $transient_name = 'listeo_reviews_' . $listing_id;
        $google_data = get_transient($transient_name);
        
        if (!empty($google_data) && isset($google_data['result']['reviews']) && is_array($google_data['result']['reviews'])) {
            $google_reviews = array_slice($google_data['result']['reviews'], 0, 15); // Limit Google reviews
            
            foreach ($google_reviews as $review) {
                if (!empty($review['text']) && strlen($review['text']) > 10) {
                    $all_reviews[] = array(
                        'type' => 'google',
                        'content' => strip_tags($review['text']),
                        'rating' => isset($review['rating']) ? floatval($review['rating']) : null,
                        'author' => isset($review['author_name']) ? $review['author_name'] : 'Google User'
                    );
                }
            }
        }
        
        return $all_reviews;
    }
    
    /**
     * Regenerate all embeddings with improved structured format
     * 
     * @param int $batch_size Number of listings to process per batch
     * @param int $start_offset Offset to start from (for resuming)
     * @return array Status information
     */
    public function regenerate_structured_embeddings($batch_size = 20, $start_offset = 0) {
        global $wpdb;
        
        if (empty($this->api_key)) {
            return array('error' => 'OpenAI API key not configured');
        }
        
        // Get all published listings
        $listings = get_posts(array(
            'post_type' => 'listing',
            'post_status' => 'publish',
            'posts_per_page' => $batch_size,
            'offset' => $start_offset,
            'fields' => 'ids'
        ));
        
        if (empty($listings)) {
            return array(
                'status' => 'complete',
                'message' => 'No more listings to process',
                'processed' => 0
            );
        }
        
        $processed = 0;
        $errors = array();
        $table_name = Listeo_AI_Search_Database_Manager::get_embeddings_table_name();
        
        foreach ($listings as $listing_id) {
            try {
                // Generate structured content
                $structured_content = $this->get_listing_content_for_embedding($listing_id);
                
                if (empty($structured_content)) {
                    $errors[] = "Empty content for listing {$listing_id}";
                    continue;
                }
                
                // Generate new embedding
                $embedding = $this->generate_embedding($structured_content);
                
                if (!$embedding) {
                    $errors[] = "Failed to generate embedding for listing {$listing_id}";
                    continue;
                }
                
                // Create content hash for tracking changes
                $content_hash = md5($structured_content);
                $compressed_embedding = Listeo_AI_Search_Database_Manager::compress_embedding_for_storage($embedding);
                
                // Update or insert embedding
                $wpdb->replace(
                    $table_name,
                    array(
                        'listing_id' => $listing_id,
                        'embedding' => $compressed_embedding,
                        'content_hash' => $content_hash,
                        'updated_at' => current_time('mysql')
                    ),
                    array('%d', '%s', '%s', '%s')
                );
                
                $processed++;
                
                // Add small delay to avoid rate limiting
                usleep(100000); // 100ms delay
                
            } catch (Exception $e) {
                $errors[] = "Error processing listing {$listing_id}: " . $e->getMessage();
            }
        }
        
        return array(
            'status' => 'processing',
            'processed' => $processed,
            'errors' => $errors,
            'next_offset' => $start_offset + $batch_size,
            'total_listings' => wp_count_posts('listing')->publish
        );
    }
    

    
    /**
     * Get reviews for a listing (both WordPress comments and Google reviews)
     * 
     * @param int $listing_id Listing post ID
     * @return string Formatted reviews content
     */
    private function get_listing_reviews($listing_id) {
        $reviews_content = '';
        $all_reviews = array();
        
        // 1. Get WordPress Comments & Reviews (same as AI Review Highlights plugin)
        $wp_comments = get_comments(array(
            'post_id' => $listing_id,
            'status' => 'approve',
            'type__in' => array('comment', 'review'),
            'number' => 25, // Limit WordPress reviews
            'orderby' => 'comment_date',
            'order' => 'DESC'
        ));
        
        foreach ($wp_comments as $comment) {
            if (!empty($comment->comment_content)) {
                $review_data = array(
                    'type' => 'wordpress',
                    'author' => $comment->comment_author,
                    'content' => strip_tags($comment->comment_content),
                    'rating' => get_comment_meta($comment->comment_ID, 'listeo-review-rating', true),
                    'criteria' => array()
                );
                
                // Get individual criteria ratings
                $criteria = array('service', 'value-for-money', 'location', 'cleanliness');
                foreach ($criteria as $criterion) {
                    $criterion_rating = get_comment_meta($comment->comment_ID, 'listeo-review-' . $criterion, true);
                    if (!empty($criterion_rating)) {
                        $review_data['criteria'][$criterion] = $criterion_rating;
                    }
                }
                
                $all_reviews[] = $review_data;
            }
        }
        
        // 2. Get Google Reviews from Listeo transient (same approach as AI Review Highlights)
        $transient_name = 'listeo_reviews_' . $listing_id;
        $google_data = get_transient($transient_name);
        
        if (!empty($google_data) && isset($google_data['result']['reviews']) && is_array($google_data['result']['reviews'])) {
            $google_reviews = $google_data['result']['reviews'];
            
            foreach ($google_reviews as $review) {
                if (!empty($review['text'])) {
                    $author = isset($review['author_name']) ? $review['author_name'] : 'Google User';
                    $rating = isset($review['rating']) ? $review['rating'] : null;
                    
                    $review_data = array(
                        'type' => 'google',
                        'author' => $author,
                        'content' => strip_tags($review['text']),
                        'rating' => $rating,
                        'criteria' => array()
                    );
                    
                    $all_reviews[] = $review_data;
                }
            }
        }
        
        // Format all reviews for embedding
        if (!empty($all_reviews)) {
            $reviews_content .= "\n--- REVIEWS ---\n";
            
            // Limit total reviews to avoid overly long embeddings
            $review_limit = 30;
            $limited_reviews = array_slice($all_reviews, 0, $review_limit);
            
            foreach ($limited_reviews as $review) {
                $source = ($review['type'] === 'google') ? 'Google' : 'WordPress';
                $reviews_content .= "{$source} review from {$review['author']}: {$review['content']}\n";
                
                if (!empty($review['rating'])) {
                    $reviews_content .= "Rating: {$review['rating']}/5\n";
                }
                
                // Add criteria ratings for WordPress reviews
                if (!empty($review['criteria'])) {
                    foreach ($review['criteria'] as $criterion => $rating) {
                        $reviews_content .= ucfirst(str_replace('-', ' ', $criterion)) . " rating: {$rating}/5\n";
                    }
                }
                
                $reviews_content .= "\n";
            }
            
            // Add summary stats
            $wp_count = count(array_filter($all_reviews, function($r) { return $r['type'] === 'wordpress'; }));
            $google_count = count(array_filter($all_reviews, function($r) { return $r['type'] === 'google'; }));
            $reviews_content .= "--- REVIEW SUMMARY ---\n";
            $reviews_content .= "Total WordPress reviews: {$wp_count}\n";
            $reviews_content .= "Total Google reviews: {$google_count}\n";
        }
        
        return $reviews_content;
    }
    
    /**
     * Analyze embedding vector for debugging
     * 
     * @param array $embedding Embedding vector
     * @return array Analysis results
     */
    public function analyze_embedding($embedding) {
        if (empty($embedding) || !is_array($embedding)) {
            return array('error' => 'Invalid embedding data');
        }
        
        $analysis = array(
            'dimensions' => count($embedding),
            'mean' => array_sum($embedding) / count($embedding),
            'min' => min($embedding),
            'max' => max($embedding),
            'std_dev' => 0
        );
        
        // Calculate standard deviation
        $mean = $analysis['mean'];
        $variance = array_sum(array_map(function($x) use ($mean) {
            return pow($x - $mean, 2);
        }, $embedding)) / count($embedding);
        
        $analysis['std_dev'] = sqrt($variance);
        
        // Check for potential issues
        $zero_count = count(array_filter($embedding, function($x) { return $x == 0; }));
        $analysis['zero_percentage'] = ($zero_count / count($embedding)) * 100;
        
        // Determine if embedding looks healthy
        $analysis['health_status'] = 'healthy';
        if ($analysis['zero_percentage'] > 50) {
            $analysis['health_status'] = 'poor - too many zeros';
        } elseif ($analysis['std_dev'] < 0.1) {
            $analysis['health_status'] = 'poor - low variance';
        } elseif (abs($analysis['mean']) > 1) {
            $analysis['health_status'] = 'unusual - high mean';
        }
        
        return $analysis;
    }
    

}
