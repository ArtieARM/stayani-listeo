<?php
// /includes/class-lds-settings.php

class LDS_Settings {

    public function __construct() {
        add_action('admin_init', [ $this, 'register_settings' ]);
        
        // Convert old GPT-5 selections to GPT-5-mini for better performance
        $current_model = get_option('lds_gpt_model', 'gpt-4.1-mini');
        if ($current_model === 'gpt-5') {
            update_option('lds_gpt_model', 'gpt-4.1-mini');
        }
    }

    public function register_settings() {
        // Register the setting group
        register_setting('lds_settings_group', 'lds_google_api_key', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('lds_settings_group', 'lds_import_limit', ['sanitize_callback' => 'absint']);
        register_setting('lds_settings_group', 'lds_description_language', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('lds_settings_group', 'lds_enable_photo_import', ['sanitize_callback' => 'absint']);
        register_setting('lds_settings_group', 'lds_photo_import_limit', ['sanitize_callback' => 'absint']);
        register_setting('lds_settings_group', 'lds_photo_storage_method', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('lds_settings_group', 'lds_enable_ai_descriptions', ['sanitize_callback' => 'absint']);
        register_setting('lds_settings_group', 'lds_openai_api_key', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('lds_settings_group', 'lds_gpt_model', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('lds_settings_group', 'lds_description_word_length', ['sanitize_callback' => 'absint']);
        register_setting('lds_settings_group', 'lds_enable_debug_mode', ['sanitize_callback' => 'absint']);
        register_setting('lds_settings_group', 'lds_search_method', ['sanitize_callback' => 'sanitize_text_field']);
        // Removed lds_default_listing_type setting

        // Add the settings section
        add_settings_section(
            'lds_main_section',
            'API and Import Settings',
            null, // Optional callback for section description
            'lds-settings-page' // Page slug where this section will be displayed
        );

        // Add the fields
        add_settings_field(
            'lds_google_api_key',
            'Google API Key',
            [ $this, 'render_api_key_field' ],
            'lds-settings-page',
            'lds_main_section'
        );
        add_settings_field(
            'lds_openai_api_key',
            'OpenAI API Key',
            [ $this, 'render_openai_api_key_field' ],
            'lds-settings-page',
            'lds_main_section'
        );
        add_settings_field(
            'lds_import_limit',
            'Listings to Import',
            [ $this, 'render_import_limit_field' ],
            'lds-settings-page',
            'lds_main_section'
        );

        // AI Description Toggle Field
        add_settings_field(
            'lds_enable_ai_descriptions',
            'Enable AI Descriptions',
            [ $this, 'render_ai_toggle_field' ],
            'lds-settings-page',
            'lds_main_section'
        );

        // GPT Model Selection Field
        add_settings_field(
            'lds_gpt_model',
            'GPT Model',
            [ $this, 'render_gpt_model_field' ],
            'lds-settings-page',
            'lds_main_section'
        );

        // Description Word Length Field
        add_settings_field(
            'lds_description_word_length',
            'Description Length',
            [ $this, 'render_description_length_field' ],
            'lds-settings-page',
            'lds_main_section'
        );

        add_settings_field(
            'lds_description_language',
            'Description Language',
            [ $this, 'render_language_field' ],
            'lds-settings-page',
            'lds_main_section'
        );

        add_settings_field(
            'lds_enable_photo_import',
            'Enable Photo Import',
            [ $this, 'render_photo_import_section' ],
            'lds-settings-page',
            'lds_main_section'
        );

        add_settings_field(
            'lds_enable_debug_mode',
            'Enable Debug Mode',
            [ $this, 'render_debug_mode_toggle_field' ],
            'lds-settings-page',
            'lds_main_section'
        );
    }

    // Render AI toggle checkbox
    public function render_ai_toggle_field() {
        $value = get_option('lds_enable_ai_descriptions', 1); // Default: enabled
        $checked = checked(1, $value, false);
        
        echo "<label>";
        echo "<input type='checkbox' name='lds_enable_ai_descriptions' id='lds_enable_ai_descriptions' value='1' {$checked} /> ";
        echo "Generate AI descriptions for imported listings";
        echo "</label>";
        echo "<p class='description'>When disabled, a simple fallback description will be used instead.</p>";
        // echo "<p class='description'><strong>Note:</strong> Disabling this will make imports much faster but descriptions will be generic.</p>";
    }

    // Render GPT model selection dropdown
    public function render_gpt_model_field() {
        $value = get_option('lds_gpt_model', 'gpt-4.1-mini'); // Default: gpt-4.1-mini
        
        echo "<div id='lds_gpt_model_container' style='margin-top: 0;'>";
        echo "<select name='lds_gpt_model'>";
        echo "<option value='gpt-4.1-mini'" . selected($value, 'gpt-4.1-mini', false) . ">GPT-4.1-mini (Fast)</option>";
        echo "<option value='gpt-5-mini'" . selected($value, 'gpt-5-mini', false) . ">GPT-5-mini (Slower, reasoning)</option>";
        echo "</select>";
        echo "<p class='description'>Choose the GPT model for generating AI descriptions. GPT-4.1-mini uses traditional parameters, while GPT-5-mini uses the latest reasoning architecture.</p>";
        echo "</div>";
        
        // JavaScript to show/hide GPT model selection based on AI descriptions checkbox
        echo "<script>
        jQuery(document).ready(function($) {
            function toggleGptModelField() {
                if ($('#lds_enable_ai_descriptions').is(':checked')) {
                    $('#lds_gpt_model_container').closest('tr').show();
                } else {
                    $('#lds_gpt_model_container').closest('tr').hide();
                }
            }
            
            // Initial state
            toggleGptModelField();
            
            // Toggle on AI descriptions checkbox change
            $('#lds_enable_ai_descriptions').on('change', function() {
                toggleGptModelField();
            });
        });
        </script>";
    }

    // Render description word length field
    public function render_description_length_field() {
        $value = get_option('lds_description_word_length', 100); // Default: 100 words
        
        echo "<div id='lds_description_length_container' style='margin-top: 0;'>";
        echo "<input type='number' name='lds_description_word_length' value='" . esc_attr($value) . "' min='50' max='500' step='10' />";
        echo "<p class='description'>Approximate number of words for AI-generated descriptions (50-500 words). This helps control description length and API costs.</p>";
        echo "</div>";
        
        // JavaScript to show/hide description length field based on AI descriptions checkbox
        echo "<script>
        jQuery(document).ready(function($) {
            function toggleDescriptionLengthField() {
                if ($('#lds_enable_ai_descriptions').is(':checked')) {
                    $('#lds_description_length_container').closest('tr').show();
                } else {
                    $('#lds_description_length_container').closest('tr').hide();
                }
            }
            
            // Initial state
            toggleDescriptionLengthField();
            
            // Toggle on AI descriptions checkbox change
            $('#lds_enable_ai_descriptions').on('change', function() {
                toggleDescriptionLengthField();
            });
        });
        </script>";
    }

    public function render_ai_cleaner_url_field() {
        $value = get_option('lds_ai_cleaner_url', '');
        $default_url = plugin_dir_url(__FILE__) . '../ai-cleaner.php';
        
        echo "<input type='url' name='lds_ai_cleaner_url' value='" . esc_attr($value) . "' class='regular-text' placeholder='" . esc_attr($default_url) . "' />";
        echo "<p class='description'>Full URL to your ai-cleaner.php file. Leave blank to use default plugin location.</p>";
        echo "<p class='description'><strong>Current default:</strong> " . esc_html($default_url) . "</p>";
        echo "<p class='description'><em>Only used when AI descriptions are enabled above.</em></p>";
    }

    // OpenAI API key field
    public function render_openai_api_key_field() {
        $value = get_option('lds_openai_api_key', '');
        echo "<input type='text' name='lds_openai_api_key' value='" . esc_attr($value) . "' class='regular-text' />";
        echo "<p class='description'>Enter your OpenAI API key. This is required for AI descriptions.</p>";
        echo "<a class='instr-btn' target='blank' href='https://docs.purethemes.net/listeo/knowledge-base/how-to-create-open-ai-api-key/'>Instructions →</a>";
    }

    public function render_api_key_field() {
        $value = get_option('lds_google_api_key', '');
        
        // Input field and test button on the same row
        echo "<div style='display: flex; align-items: center; gap: 10px; margin-bottom: 8px;'>";
        echo "<input type='text' name='lds_google_api_key' id='lds_google_api_key' value='" . esc_attr($value) . "' class='regular-text' style='flex: 1;' />";
        echo "<button type='button' id='lds_test_api_key' class='button button-secondary' style='background: #dcf2dc; color: #148a15; border: none; white-space: nowrap;'>Test API Key</button>";
        echo "</div>";
        
        // Test result span on its own line
        echo "<div style='margin-bottom: 8px;'>";
        echo "<span id='lds_api_test_result' style='font-weight: bold;'></span>";
        echo "</div>";
        
        echo "<p class='description'>Enter your Google Places API key <strong style='color: #222;'>(restricted to your domain)</strong>.</p>";
        echo "<a class='instr-btn' target='_blank' href='https://docs.purethemes.net/listeo/knowledge-base/creating-google-maps-api-key/'>Instructions →</a>";
        
        
        // Security notice (blue/info)

        // Quota warning (red)
        echo "<p style='margin-top: 10px; border-radius: 5px; padding: 12px 14px; font-size: 14px; line-height: 20px;background: #e3f6ff; color: #24619f;'>
        <strong>Cost Example</strong>: Importing 100 businesses typically costs $2-4 in Google API fees. Start with small batches and monitor your Google Cloud billing closely.  </p> ";

        // Quota warning (yellow)
        echo "<p style='margin-top: 10px; border-radius: 5px; padding: 12px 14px; font-size: 14px; line-height: 20px; background: #ffe0e0; color: #a71717ff;'>
        <strong>Note:</strong> We do not take responsibility for any charges from Google related to your usage. Monitor your API usage and to avoid surprise charges and <strong>set up alerts in Google Clouds</strong>. </p>";

        // WARNING notice
        echo "<div style='background: #fff3de; color: #885c0e; padding: 15px; margin: 10px 0; border-radius: 4px;'>
<strong>⚠️ Heads up!</strong> It uses Google Places data and storing that data in WordPress might go against Google’s Terms.  Use it responsibly - heavy or improper use could lead to API limits or account suspension. We do not take responsibility for any issues that come up. :)</div>";

        // Add JavaScript for the test button
        echo "<script>
        jQuery(document).ready(function($) {
            $('#lds_test_api_key').on('click', function() {
                var apiKey = $('#lds_google_api_key').val().trim();
                var button = $(this);
                var resultSpan = $('#lds_api_test_result');
                
                if (!apiKey) {
                    resultSpan.html('<span style=\"color: #d63384;\">Please enter an API key first</span>');
                    return;
                }
                
                button.prop('disabled', true).text('Testing...');
                resultSpan.html('<span style=\"color: #0d6efd;\">Testing Places API...</span>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'lds_test_api_key',
                        api_key: apiKey,
                        nonce: '" . wp_create_nonce('lds_test_api_key_nonce') . "'
                    },
                    success: function(response) {
                        if (response.success) {
                            resultSpan.html('<span style=\"color: #198754;\">' + response.data.message + '</span>');
                        } else {
                            resultSpan.html('<span style=\"color: #d63384;\">✗ ' + response.data.message + '</span>');
                        }
                    },
                    error: function() {
                        resultSpan.html('<span style=\"color: #d63384;\">✗ Network error occurred</span>');
                    },
                    complete: function() {
                        button.prop('disabled', false).text('Test API Key');
                    }
                });
            });
        });
        </script>";
    }

    public function render_import_limit_field() {
        $value = get_option('lds_import_limit', 20); 
        echo "<input type='number' name='lds_import_limit' value='" . esc_attr($value) . "' min='1' max='20' />"; 
        echo "<p class='description'>Maximum 20 listings per import. Higher values may timeout on shared hosting.</p>";
        echo "<p class='description' style='color: #666; font-size: 12px;'><strong>Note:</strong> Google returns the same results for repeated searches. After importing, use a different search query to find additional listings.</p>";
    }

    public function render_debug_mode_toggle_field() {
        $value = get_option('lds_enable_debug_mode', 0); 
        $checked = checked(1, $value, false);
        
        echo "<label>";
        echo "<input type='checkbox' name='lds_enable_debug_mode' value='1' {$checked} /> ";
        echo "Enable logging for debugging purposes";
        echo "</label>";
        echo "<p class='description'>When enabled, the plugin will write detailed information to a <code>debug-lds.log</code> file in your <code>/wp-content/</code> directory.</p>";
        echo "<p class='description'><strong>Note:</strong> This should be left disabled during normal use to improve performance and save disk space.</p>";
    }

    public function render_language_field() {
        $current_lang = get_option('lds_description_language', 'site-default');
        $site_locale = get_locale();
        $site_lang_name = \Locale::getDisplayLanguage($site_locale, 'en');
        $available_locales = get_available_languages();

        ?>
        <select name="lds_description_language">
            <option value="site-default" <?php selected($current_lang, 'site-default'); ?>>
                WordPress Site Language (Currently: <?php echo esc_html($site_lang_name); ?>)
            </option>
            
            <?php
            $language_names = [];
            if (!empty($available_locales)) {
                foreach ($available_locales as $locale) {
                    $language_names[] = \Locale::getDisplayLanguage($locale, 'en');
                }
            }
            
            if ($current_lang !== 'site-default' && !in_array($current_lang, $language_names)) {
                $language_names[] = $current_lang;
            }

            $language_names = array_unique($language_names);
            sort($language_names);

            foreach ($language_names as $lang_name) {
                echo '<option value="' . esc_attr($lang_name) . '" ' . selected($current_lang, $lang_name, false) . '>';
                echo esc_html($lang_name);
                echo '</option>';
            }
            ?>
        </select>
        <p class="description">Select the language for AI-generated descriptions and Google Places data (including reviews). This list is dynamically generated from the languages installed on your WordPress site.</p>
        <p class="description"><strong>Note:</strong> This setting affects the language of reviews fetched from Google Places API.</p>
        <?php
        
        if (!extension_loaded('intl')) {
            echo '<p style="color: #e74c3c;"><strong>Warning:</strong> The `intl` PHP extension is not enabled on your server. Language name display may be limited.</p>';
        }
    }

    // New method that combines photo settings
    public function render_photo_import_section() {
        $photo_enabled = get_option('lds_enable_photo_import', 0);
        $photo_limit = get_option('lds_photo_import_limit', 0);
        $storage_method = get_option('lds_photo_storage_method', 'google');
        
        $checked = checked(1, $photo_enabled, false);
        
        // Main checkbox
        echo "<label>";
        echo "<input type='checkbox' name='lds_enable_photo_import' id='lds_enable_photo_import' value='1' {$checked} /> ";
        echo "Import photos from Google Places";
        echo "</label>";
        // Quota warning (red)
        echo "<p style='margin-top: 10px; border-radius: 5px; padding: 12px 14px; font-size: 14px; line-height: 20px;background: #fff3de; color: #885c0e;'>
            Downloading photos may violate Google's Terms of Service. Hosting them from Google via API is allowed but will be costly (~$0.05 per image request and each page load triggers it). </p> ";

        // Photo settings container (hidden when checkbox is unchecked)
        echo "<div id='lds_photo_settings' style='margin-top: 15px; padding: 15px; border: 1px solid #ddd; border-radius: 5px; background: #f9f9f9;'>";
        
        // Number of photos field
        echo "<h4 style='margin-top: 0;'>Number of Photos to Import</h4>";
        echo "<input type='number' name='lds_photo_import_limit' value='" . esc_attr($photo_limit) . "' min='0' max='5' />"; 
        echo "<p class='description'>Max number of photos to import per listing (0-5).</p>";
        echo "<p class='description'><strong>Note:</strong> Photos will increase Google API usage and cost</p>";
        
        echo "<hr style='margin: 20px 0;'>";
        
        // Photo storage method field
        echo "<h4>Photo Storage Method</h4>";
        ?>
        <fieldset>
            <label>
                <input type="radio" name="lds_photo_storage_method" value="google" <?php checked($storage_method, 'google'); ?> />
                <span><?php _e('Display from Google servers (Costly)', 'listeo_core'); ?></span>
            </label>
            <p style="margin-top: 0px; border-radius: 5px; padding: 12px 14px; font-size: 14px; line-height: 20px;background: #d9effa; color: #24619f; } ">
            This is method compliant with Google's Terms of Service. Photos are loaded directly from Google using their official API. <br><br><strong>Unfortunately this is costly because will increase API usage, as each page load triggers image requests (~$0.05 per photo viewed).</strong></p>
            <br>
            <label>
                <input type="radio" name="lds_photo_storage_method" value="download" <?php checked($storage_method, 'download'); ?> id="download-method-radio" />
                <span><?php _e('Download to media library (Risk of TOS violation)', 'listeo_core'); ?></span>
                <p style='margin-top: 5px; border-radius: 5px; padding: 12px 14px; font-size: 14px; line-height: 20px; background: #d9effa; color: #24619f;'>Photos should not be downloaded and stored on external servers due to Google's Terms of Service.</p>
            </label>
        </fieldset>
        <?php
        
        echo "</div>"; // End photo settings container
        
        // JavaScript to show/hide photo settings
        echo "<script>
        jQuery(document).ready(function($) {
            function togglePhotoSettings() {
                if ($('#lds_enable_photo_import').is(':checked')) {
                    $('#lds_photo_settings').show();
                } else {
                    $('#lds_photo_settings').hide();
                }
            }
            
            // Initial state
            togglePhotoSettings();
            
            // Toggle on checkbox change
            $('#lds_enable_photo_import').on('change', function() {
                togglePhotoSettings();
            });
        });
        </script>";
    }

    public function render_photo_limit_field() {
        $value = get_option('lds_photo_import_limit', 0); 
        echo "<input type='number' name='lds_photo_import_limit' value='" . esc_attr($value) . "' min='0' max='5' />"; 
        echo "<p class='description'>Max number of photos to import per listing (0-5).</p>";
    }

    // Add this render method to the class:
    public function render_photo_storage_method_field() {
        $value = get_option('lds_photo_storage_method', 'google');
        ?>
        <fieldset>
            <label>
                <input type="radio" name="lds_photo_storage_method" value="google" <?php checked($value, 'google'); ?> />
                <span><?php _e('Display from Google servers', 'listeo_core'); ?></span>
            </label>
        <p style="margin-top: 0px; border-radius: 5px; padding: 12px 14px; font-size: 14px; line-height: 20px; background: #fff3de; color: #885c0e; ">
This is <strong>method compliant with Google’s Terms of Service</strong>. Photos are loaded directly from Google using their official API. <br><br><strong>This will increase API usage, as each page load triggers image requests (~$0.05 per photo viewed).</strong></p>
        </p>
            <br>
            <label>
                <input type="radio" name="lds_photo_storage_method" value="download" <?php checked($value, 'download'); ?> id="download-method-radio" />
                <span><?php _e('Download to media library (Risk of TOS violation)', 'listeo_core'); ?></span>
                <p style='margin-top: 5px; border-radius: 5px; padding: 12px 14px; font-size: 14px; line-height: 20px; background: #ffe0e0; color: #a71717ff;'>Photos should not be downloaded and stored on external servers due to Google's Terms of Service.</p>
            </label>
        </fieldset>
        
        <!-- <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#download-method-radio').on('click', function(e) {
                if (!confirm('Are you sure you want to enable downloading photos to your media library?\n\nThis method violates Google\'s Terms of Service and may result in:\n• API suspension\n• Legal issues\n• Account termination\n\nWe strongly recommend using the "Display from Google servers" option instead.')) {
                    e.preventDefault();
                    // Switch back to the Google method
                    $('input[name="lds_photo_storage_method"][value="google"]').prop('checked', true);
                    return false;
                }
            });
        });
        </script> -->
        <?php
    }
}