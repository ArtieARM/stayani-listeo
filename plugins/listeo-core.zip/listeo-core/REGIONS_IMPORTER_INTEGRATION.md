# Listeo Core Importers Integration

## Overview
Both the **Regions Importer** and **Translation Importer** functionalities have been successfully integrated into Listeo Core as core features, replacing the standalone plugins with better organization and enhanced safety measures.

## Implementation Summary

### Files Modified/Created:

#### Regions Importer:
1. **NEW: `wp-content/plugins/listeo-core/includes/class-listeo-core-regions-importer.php`**
   - Main regions importer class with full functionality
   - Includes robust conflict detection and safety checks
   - Proper translation support using 'listeo_core' text domain

#### Translation Importer:
2. **NEW: `wp-content/plugins/listeo-core/includes/class-listeo-core-translation-importer.php`**
   - Complete translation importer functionality 
   - Theme detection (Listeo/WorkScout) with comprehensive language support
   - Real-time availability checking via AJAX

#### Core Files Modified:
3. **MODIFIED: `wp-content/plugins/listeo-core/listeo-core.php`**
   - Added conflict detection for both importers
   - Integrated initialization on `plugins_loaded` hook
   - Added admin notices for plugin conflicts

4. **MODIFIED: `wp-content/plugins/listeo-core/includes/class-listeo-core-admin.php`**
   - Added `add_regions_importer_menu()` method (under Listings)
   - Added `add_translation_importer_menu()` method (under Settings)
   - Added respective callback methods

### Key Safety Features:

✅ **Multi-Layer Conflict Detection**: 
- Class existence checks for both standalone plugins
- Plugin activation verification 
- Safe function availability checks
- Graceful fallback with clear admin notices

✅ **Error Prevention**:
- No fatal PHP errors if standalone plugins exist
- Clear user instructions for conflict resolution
- Proper hook priorities and initialization timing
- Safe loading in `plugins_loaded` hook

✅ **Enhanced Organization**:
- Regions Importer: **Listings → Regions Importer** (listing-specific functionality)
- Translation Importer: **Settings → Translation Importer** (site-wide configuration)

### Menu Locations:

#### Regions Importer:
```
WordPress Admin → Listings → Regions Importer
```

#### Translation Importer:
```
WordPress Admin → Settings → Translation Importer
```

## Migration Instructions

### For Site Administrators:

**BEFORE**:
- Regions importer was a separate top-level menu item
- Translation importer was a separate top-level menu item

**AFTER**: 
- Regions importer is under **Listings → Regions Importer**
- Translation importer is under **Settings → Translation Importer**

**IF CONFLICTS OCCUR**: 
1. Deactivate standalone "Regions Importer" plugin
2. Deactivate standalone "Translation Importer" plugin
3. Both integrated versions will automatically become available

### For Developers:

#### Regions Importer:
- All functionality remains identical to standalone version
- Same region taxonomy integration and import process
- Same UI and user experience
- Text domain changed from 'dynamic-regions-importer' to 'listeo_core'

#### Translation Importer:
- All functionality remains identical to standalone version
- Same theme detection and language file download process
- Same AJAX availability checking and mismatch detection
- Text domain changed from 'pt-translation-importer' to 'listeo_core'

## Conflict Resolution

If you see warnings about plugin conflicts:

1. Go to **Plugins → Installed Plugins**
2. Find and deactivate:
   - "Regions Importer" (standalone version)
   - "Translation Importer" (standalone version) 
3. The integrated versions will automatically become available in their new locations

## Technical Details

### Regions Importer:
- **Text Domain**: 'listeo_core'
- **Capability Required**: 'manage_options'
- **Menu Slug**: 'listeo-regions-importer'  
- **Parent Menu**: 'edit.php?post_type=listing'
- **API Endpoint**: https://purethemes.net/import-regions

### Translation Importer:
- **Text Domain**: 'listeo_core'
- **Capability Required**: 'manage_options'
- **Menu Slug**: 'listeo-translation-importer'
- **Parent Menu**: 'options-general.php' (WordPress Settings)
- **API Endpoints**: 
  - Listeo: https://purethemes.net/listeo-theme-translations/
  - WorkScout: https://purethemes.net/workscout-theme-translations/

## Verification

Both integrations include automatic verification:
- Class existence checks for standalone plugins
- Plugin conflict detection with clear admin notices
- Safe initialization with proper error handling
- Theme compatibility detection (Translation Importer)

No additional configuration is required - both integrations work automatically when Listeo Core is active and no conflicting standalone plugins are present.

## Benefits of Integration

1. **Better Organization**: Logical menu placement based on functionality
2. **Reduced Plugin Count**: Core functionality instead of separate plugins
3. **Enhanced Safety**: Multiple layers of conflict detection
4. **Consistent Experience**: Unified styling and error handling
5. **Easier Maintenance**: Single codebase to maintain and update
